package com.example.milestone6;

import com.example.milestone6.IO.addressBook;
import com.example.milestone6.IO.businessService;
import com.example.milestone6.IO.fileIOService;
import com.example.milestone6.contacts.baseContact;
import com.example.milestone6.contacts.businessContact;
import com.example.milestone6.contacts.personContact;

import java.io.IOException;
import java.util.*;
public class ConsoleApp {
	public static void printMenu() {
		System.out.println("Main menu. Please select an option (1-9):");
		System.out.println("(1) List all contacts \n(2) List all personal contacts\n(3) List all business contacts \n(4) Search for a contact \n(5) Update/Edit a contact \n(6) Create a new Contact \n(7) Delete a contact \n(11) Load all contacts from file \n(12) Save all contacts to a file \n(0) Exit");
	}
	public static void menuHandler(int selection , addressBook contacts , businessService BService) {
		ArrayList<baseContact> temp;
		Scanner input = new Scanner(System.in);
		switch(selection) {
		case 1:
			temp= contacts.sortBy("name", true);
			for(baseContact n : temp) {
				System.out.println(n);
			}
			break;
		case 2:
			temp = contacts.getPeople();
			for(baseContact n : temp) {
				System.out.println(n);
			}
			break;
		case 3:
			temp = contacts.getBusinesses();
			for(baseContact n : temp) {
				System.out.println(n);
			}
			break;
		case 4:
			//inner menu for searching a contact
			while(0==0){
				System.out.print("How would you like to search?\n(1) Name \n(2) Email \n(0) Back");
				int searchMethod  = 0;
				String searchInfo = "";
				try {
					searchMethod = input.nextInt();
				}catch(Error e) {
					System.out.println("Please input a valid integer");
				}
				//clears the \n from the previous input
				input.nextLine();
				if(searchMethod < 0 || searchMethod > 2) {
					System.out.println("Please pick something from the menu\n(1) Name \n(2) Email \n(0) Back");
				}
				else if(searchMethod == 1) {
					System.out.print("Please enter the first and last name of the contact, with a space separating them: ");
					searchInfo = input.nextLine();
					System.out.println();
					System.out.println("\n\n Here is the requested contact: \n" + contacts.searchFor("name", searchInfo));
					break;
				}
				else if(searchMethod == 2) {
					System.out.print("Please enter the contact's email: ");
					searchInfo = input.nextLine();
					System.out.println();
					System.out.println("\n\n Here is the requested contact: \n"+contacts.searchFor("email", searchInfo));
					break;
				}
				else {
					break;
				}
			}
			break;
		case 5:
			boolean exit = false;
			temp= contacts.sortBy("name", true);
			int m = 1;
			do {
				System.out.println("\nPlease pick a contact (1-" + temp.size() + "):");
				for(baseContact n : temp) {
					System.out.println("("+m+") "+n);
					m++;
				}
				System.out.print("(0)Exit\nContact #: ");
				try {
					//reusing m for the input
					m = input.nextInt();
					input.nextLine();
				}catch(Error e){
					System.out.println("Please enter a valid integer");
				}
				if(m == 1 || m == 2){
					exit = true;
				}
				else if(m ==0) {
					break;
				}
				else {
					System.out.println("Please input a valid choice!");
				}
			}while(!exit);
			if(m ==0)
				break;
			
			if(temp.toArray()[m-1] instanceof personContact)
				((personContact)temp.toArray()[m-1]).editContact((personContact)temp.toArray()[m-1]);
			else
				((businessContact)temp.toArray()[m-1]).editContact((businessContact)temp.toArray()[m-1]);
			
			break;
		case 6:
			System.out.print("Will the contact be for a \n(1)Person \n(2)Business\n(0)Cancel\nSelection: ");
			int n = 0;
			baseContact tempContact;
			try {
				//reusing m for the input
				n = input.nextInt();
				input.nextLine();
			}catch(Error e){
				System.out.println("Please enter a valid integer");
			}
			if(n == 1) {
				tempContact = new personContact();
				((personContact)tempContact).constructContact();
				contacts.addContact(tempContact);
			}
			else if(n == 2) {
				tempContact = new businessContact();
				((businessContact)tempContact).constructContact();
				contacts.addContact(tempContact);
			}
			else {
				
			}
			break;
		case 7:
			temp= contacts.sortBy("name", true);
			System.out.println("Please pick a contact (1-" + temp.size() + "):");
			int s = 1;
			for(baseContact r : temp) {
				System.out.println("("+s+") "+r);
				s++;
			}
			System.out.print("Contact #: ");
			try {
				//reusing m for the input
				s = input.nextInt();
				input.nextLine();
			}catch(Error e){
				System.out.println("Please enter a valid integer");
			}
			if(temp.toArray()[s-1] instanceof personContact)
				contacts.removeContact((personContact)temp.toArray()[s-1]);
			else
				contacts.removeContact((businessContact)temp.toArray()[s-1]);
			
			break;
		case 11:
			System.out.println("Loading all contacts from Contacts.json");
			//BService.loadContacts();
			break;
		case 12:
			System.out.println("Saving all contacts to Contacts.json");
			//BService.saveContacts();
			break;
		default:
			break;
			
		}
		System.out.println("\n\n");
	}
	
	public static void main(String[] args) throws IOException , InputMismatchException{
		fileIOService prebuilt = new fileIOService();
		businessService BService = new businessService();
		addressBook contacts = BService.getAddressBook();
		Scanner ask = new Scanner(System.in);
		//contacts.addContact(new personContact("Hagen.jpg" , "Ian Hagen" , "tf2@gmail.com" , "6612963236" ,  "Raintree Ln" , "Santa Clarita" , "CA", "91390" , "United States" , true , "10/21/199" , "TF2 god"));
		//contacts.addContact(new businessContact("BuRGer.png" , "HabitBurger" , "HabitBurger@hotmail.com" , "66113123123" ,  "McBean pkwy" , "Hueston" , "CA", "91390" , "United States" , false , "9-17:00 Mon-Thur" , "www.Habit.com" ));
		
		boolean exit = false;
		int input = 13;
		
		//Tests whether or not the user enters in an integer
		do{
			printMenu();
			System.out.print("Enter your selection here: ");
			try {
				input = ask.nextInt();
				System.out.println();
			}
			catch(InputMismatchException e) {
				System.out.println("ERROR: Not a valid input ");
			}
			ask.nextLine();
			if(input == 0)
				exit = true;
			else if(input > 12 && input < 1)
				System.out.printf("\n%d is not a valid option between 1 and 12");
			else
				menuHandler(input,contacts,BService);
			
		}while(exit == false);
		System.out.println("Closing program!!");
		System.out.println(contacts.getContacts());
		
		
	}
}
