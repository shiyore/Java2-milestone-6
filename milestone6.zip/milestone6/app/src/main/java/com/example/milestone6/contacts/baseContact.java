package com.example.milestone6.contacts;


import java.util.*;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(
		use = JsonTypeInfo.Id.NAME,
		include = JsonTypeInfo.As.PROPERTY,
		property = "type")
@JsonSubTypes({
	@Type(value = personContact.class, name = "Person"),
	@Type(value = businessContact.class , name = "Business")
})
public class baseContact {
	private String pic,name,email,number, street , city, state , zip , country;
	private boolean isFavorite;
	protected boolean Business , Person;
	
	public baseContact() {
		/**pic = "";
		name = "";
		email = "";
		number = "";
		street = "";
		city = "";
		state = "";
		zip = "";
		country = "";
		isFavorite = false;
		Business = false;
		Person = false;**/

		
	}
	public boolean isPerson() {
		return Person;
	}
	public void setPerson(boolean person) {
		Person = person;
	}
	public baseContact( String pic, String name , String email , String number, String street, String city, String state, String zip , String country, boolean isFavorite){
		this.pic = pic;
		this.name = name;
		this.email = email;
		this.number = number;
		this.isFavorite = isFavorite;
		this.street = street;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.country = country;
		Business = false;
		Person = false;
	}
	
	
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		//System.out.println("Changing street of " + getName() + " to " + street);
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		//System.out.println("Changing city of " + getName() + " to " + city);
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		//System.out.println("Changing state of " + getName() + " to " + state);
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		//System.out.println("Changing zip of " + getName() + " to " + zip);
		this.zip = zip;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		//System.out.println("Changing country of " + getName() + " to " + country);
		this.country = country;
	}
	public boolean isBusiness() {
		return Business;
	}
	public void setBusiness(boolean business) {
		Business = business;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		//System.out.println("Changing pic of " + getName() + " to " + pic);
		this.pic = pic;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		//System.out.println("Changing name of " + getName() + " to " + name);
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		//System.out.println("Changing email of " + getName() + " to " + email);
		this.email = email;
	}
	public boolean isFavorite() {
		return isFavorite;
	}
	public void setFavorite(boolean isFavorite) {
		this.isFavorite = isFavorite;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		//System.out.println("Changing number of " + getName() + " to " + number);
		this.number = number;
	}
	
	//outputs the phonenumber with dashes in it
	public String numberWithDashes() {
		String num = "";
		if(number.length() == 10) {
			num =  number.substring(0,3) + "-";
			num += number.substring(3,6) + "-";
			num += number.substring(6,number.length());
		}
		else {
			num = number;
		}
		return num;
	}
	//outputs the name and number
	public String toString() {
		return (name + "\t\t" + numberWithDashes());
	}
	
	//concept methods for calling, texting, and emailing that will later be implemented, fully, on android
	public void callTo() {
		System.out.println("Calling " + getName());
	}
	public void emailTo() {
		System.out.println("Opening app to compose email to " + getName());
	}
	public void textTo() {
		System.out.println("Opening app to compose text message to " + getName());
	}
	
}
