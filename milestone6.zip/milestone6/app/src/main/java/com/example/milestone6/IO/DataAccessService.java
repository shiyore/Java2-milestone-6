package com.example.milestone6.IO;
import com.example.milestone6.contacts.contactList;

import com.example.milestone6.contacts.*;
public interface DataAccessService {
	void writeAllData(addressBook contactApp);
	contactList readAllData();
	
}
