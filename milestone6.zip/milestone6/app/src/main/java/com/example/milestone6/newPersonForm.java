package com.example.milestone6;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class newPersonForm extends AppCompatActivity {
    Button b_okay, b_cancel;
    EditText et_age, et_name , et_picnumber;

    int positionToEdit = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_new_person_form);

        /**b_okay = findViewById(R.id.b_okay);
        b_cancel = findViewById(R.id.b_cancel);

        et_age = findViewById(R.id.et_age);
        et_name = findViewById(R.id.et_name);
        et_picnumber = findViewById(R.id.et_picnumber);**/

        //listen for data
        Bundle incomingIntent = getIntent().getExtras();

        if(incomingIntent != null){
            String name = incomingIntent.getString("name");
            int age = incomingIntent.getInt("age");
            int pic = incomingIntent.getInt("pic");

            et_name.setText(name);
            et_age.setText(Integer.toString(age));
            et_picnumber.setText(Integer.toString(pic));
            positionToEdit = incomingIntent.getInt("edit");
        }

        b_okay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get info from text fields
                String newName = et_name.getText().toString();
                String newAge = et_age.getText().toString();
                String newPic = et_picnumber.getText().toString();

                Intent i = new Intent(v.getContext(), MainActivity.class);
                i.putExtra("edit" , positionToEdit);
                i.putExtra("name" , newName);
                i.putExtra("age" , newAge);
                i.putExtra("pic" , newPic);
                startActivity(i);
            }
        });

    }
}
