package com.example.milestone6.IO;

import com.example.milestone6.contacts.*;
import java.util.*;

import com.example.milestone6.contacts.baseContact;
import com.fasterxml.jackson.annotation.JsonIgnore;
public class addressBook {
	private Map<String , baseContact> contacts , email , city , country;
	private ArrayList<baseContact> favs;
	
	public addressBook() {
		contacts = new HashMap<>(200);
		email = new HashMap<>(200);
		city = new HashMap<>(200);
		country = new HashMap<>(200);
		favs = new ArrayList<baseContact>();
	}
	public void addContact(baseContact contact) {
		String temp = contact.toString().split("\t")[0];
		System.out.println("New contact: " + temp  + " added");
		contacts.putIfAbsent(temp, contact);
		email.putIfAbsent((String)contact.getEmail(), contact);
		city.put((String)contact.getCity(), contact);
		country.putIfAbsent((String)contact.getCountry(), contact);
	}
	//removes a contact given a contact or name
	public void removeContact(baseContact contact) {
		System.out.println("Removing contact: " + contact.toString());
		contacts.remove(contact.toString().split("\t")[0]);
	}
	public void removeContact(String name) {
		System.out.println("Removing contact: " + name);
		contacts.remove(name);
	}
	
	//returns a contact given a name
	public baseContact getContact(String name) {
		if(name.split(" ").length <= 2) {
			if(contacts.get(name) instanceof businessContact)
				return (businessContact) contacts.get(name);
			else
				return (personContact) contacts.get(name);
		}
		else {
			System.out.println("the name given does not fit the criteria (Firstname Lastname)");
			return null;
		}
	}
	
	public void setContacts(HashMap<String , baseContact> contacts){
		this.contacts = contacts;
	}
	public void setContacts(ArrayList<baseContact> contacts) {
		this.contacts = new HashMap<String , baseContact>(200);
		for(baseContact n : contacts) {
			addContact(n);
		}
	}
	public Map<String, baseContact> getContacts(){
		return contacts;
	}
	@JsonIgnore
	public ArrayList<baseContact> getFavorites() {
		loadFavorites();
		return favs;
	}
	private void loadFavorites() {
		favs = new ArrayList<baseContact>();
		for (Map.Entry<String, baseContact> n : contacts.entrySet()) {
			if(n.getValue().isFavorite())
				favs.add(n.getValue());
		}
	}
	@JsonIgnore
	public ArrayList<baseContact> getBusinesses(){
		ArrayList<baseContact> temp = new ArrayList<baseContact>();
		for (Map.Entry<String, baseContact> n : contacts.entrySet()) {
			if(n.getValue() instanceof businessContact)
				temp.add((businessContact)n.getValue());
		}
		return temp;
	}
	@JsonIgnore
	public ArrayList<baseContact> getPeople(){
		ArrayList<baseContact> temp = new ArrayList<baseContact>();
		for (Map.Entry<String, baseContact> n : contacts.entrySet()) {
			if(n.getValue().isPerson() && n.getValue() instanceof personContact)
				temp.add((personContact)n.getValue());
		}
		return temp;
	}
	
	//returns a sorted arraylist of contacts
	public ArrayList<baseContact> sortBy(String type , boolean ascending){
		ArrayList<baseContact> temp = new ArrayList<baseContact>();
		TreeMap<String , baseContact> sorted = new TreeMap<>();
		switch(type) {
		case "name":
			sorted.putAll(contacts);
			if(ascending) {
				for(Map.Entry<String , baseContact> n : sorted.entrySet()) {
					temp.add(n.getValue());
				}
			}
			else {
				for(Map.Entry<String , baseContact> n : sorted.entrySet()) {
					temp.add(0,n.getValue());
				}
			}
			break;
		case "email":
			sorted.putAll(email);
			if(!ascending) {
				for(Map.Entry<String , baseContact> n : sorted.entrySet()) {
					temp.add(n.getValue());
				}
			}
			else {
				for(Map.Entry<String , baseContact> n : sorted.entrySet()) {
					temp.add(0,n.getValue());
				}
			}
			break;
		case "city":
			sorted.putAll(city);
			if(!ascending) {
				for(Map.Entry<String , baseContact> n : sorted.entrySet()) {
					temp.add(n.getValue());
				}
			}
			else {
				for(Map.Entry<String , baseContact> n : sorted.entrySet()) {
					temp.add(0,n.getValue());
				}
			}
			break;
		case "country":
			sorted.putAll(country);
			if(!ascending) {
				for(Map.Entry<String , baseContact> n : sorted.entrySet()) {
					temp.add(n.getValue());
				}
			}
			else {
				for(Map.Entry<String , baseContact> n : sorted.entrySet()) {
					temp.add(0,n.getValue());
				}
			}
			break;
		default:
			sorted.putAll(contacts);
			if(!ascending) {
				for(Map.Entry<String , baseContact> n : sorted.entrySet()) {
					temp.add(n.getValue());
				}
			}
			else {
				for(Map.Entry<String , baseContact> n : sorted.entrySet()) {
					temp.add(0,n.getValue());
				}
			}
			break;
		}
		return temp;
	}
	
	//searches through the contact list to find a contact/contacts with the given value and search type (name or birthday)
	public ArrayList searchFor(String type , String value){
		ArrayList<baseContact> temp ;
		String stripped = type.split(" ")[0].toLowerCase();
		switch(stripped) {
		case "name":
			temp = new ArrayList<baseContact>();
			temp.add(getContact(value));
			//System.out.println(getContact(value));
			break;
		case "birthday":
			temp = new ArrayList<baseContact>();
			temp.addAll(getPeople());
			for( Object n : temp.toArray()) {
				n = (personContact)n;
				if(!((personContact) n).getBirthDay().equals(value))
					temp.remove(n);
			}
			break;
		case "email":
			temp = new ArrayList<baseContact>();
			temp.add(email.get(value));
			//System.out.println(getContact(value));
			break;
		case "city":
			temp = new ArrayList<baseContact>();
			temp.add(city.get(value));
			//System.out.println(getContact(value));
			break;
		case "country":
			temp = new ArrayList<baseContact>();
			temp.add(country.get(value));
			//System.out.println(getContact(value));
			break;
		default:
			temp = new ArrayList<baseContact>();
			System.out.println(value+" is not a valid search method as of now.");
			break;
		}
		
		return temp;
	}
	
	public void printHash() {
		System.out.println(city);
	}
	
	
	public static void main(String[] args) {
		addressBook contacts = new addressBook();
		personContact me = new personContact("" , "Aiden Yoshioka" , "Shiyore@gmail.com" , "6615423117" , "Raintree Ln" , "Santa Clarita" , "CA", "91390" , "United States" ,true , "03/26/1999" , "Me myself alone");
		contacts.addContact(me);
		contacts.addContact(new personContact("" , "John Smith" , "asdfasd@gmail.com" , "66113123123" ,  "Raintree Ln" , "Santa Clarita" , "CA", "91390" , "United States" ,false , "03/22/2013" , "Sucks to Suck" ));
		contacts.loadFavorites();
		//System.out.println(contacts.searchFor("bIrthday", "03/26/1999"));
		//System.out.println(contacts.sortBy("name" , true));
		//System.out.println(contacts.sortBy("email" , true));
		System.out.println(contacts.searchFor("city" , "Santa Clarita"));
		contacts.printHash();
		
	}
}
