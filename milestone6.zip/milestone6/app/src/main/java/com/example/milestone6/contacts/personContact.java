package com.example.milestone6.contacts;

import java.util.*;

public class personContact extends baseContact{
	private String birthday, description;
	
	public personContact() {
		/**super();
		System.out.println("new person created");
		birthday = "";
		description = "";
		super.Person = true;**/
		System.out.println("person constructor ran");

	}
	public personContact(String pic , String name , String email , String number , String street, String city, String state, String zip , String country, boolean isFavorite , String birthday , String description) {
		super(pic, name , email , number, street , city, state, zip , country, isFavorite);
		this.birthday = birthday;
		this.description = description;
		super.Person = true;
	}
	
	public void constructContact() {
		Scanner input = new Scanner(System.in);
		System.out.print("Pic: ");
		setPic(input.nextLine());
		System.out.print("\nName: ");
		setName(input.nextLine());
		System.out.print("\nEmail: ");
		setEmail(input.nextLine());
		System.out.print("\nNumber: ");
		setNumber(input.nextLine());
		System.out.print("\nStreet: ");
		setStreet(input.nextLine());
		System.out.print("\nCity: ");
		setCity(input.nextLine());
		System.out.print("\nState: ");
		setState(input.nextLine());
		System.out.print("\nZIP code: ");
		setZip(input.nextLine());
		System.out.print("\nCountry: ");
		setCountry(input.nextLine());
		System.out.print("\nBirthday: ");
		birthday = input.nextLine();
		System.out.print("\nDescription: ");
		description = input.nextLine();
	}
	
	public String getBirthDay() {
		return birthday;
	}

	public void setBirthDay(String birthDay) {
		//System.out.println("Changing birthday of " + getName() + " to " + birthDay);
		this.birthday = birthDay;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		//System.out.println("Changing description of " + getName() + " to " + description);
		this.description = description;
	}
	
	public void editContact(personContact contact) {
		Scanner input =  new Scanner(System.in);
		String temp = "";
		int num = 15;
		boolean exit = false;
		do{
			System.out.printf("\nWhat would you like to edit?: \n(1)Pic: %s\n(2)Name: %s \n(3)Email: %s \n(4)Number: %s \n(5)Street %s \n(6)City: %s \n(7)State: %s \n(8)ZIP: %s\n(9)Country: %s \n(10)Favorite: "+contact.isFavorite()+"\n(11)Birthday: %s \n(12)Description: %s\n(0)Exit\n", contact.getPic() , contact.getName(), contact.getEmail() , contact.getNumber(), contact.getStreet() , contact.getCity() , contact.getState() , contact.getZip(), contact.getCountry() , contact.getBirthDay(), contact.getDescription());
			System.out.print("\nWhat would you like to edit? (1-12):");
			try {
				num = input.nextInt();
				input.nextLine();
			}catch(Error e) {
				System.out.println("Please input a valid integer");
			}
			switch(num) {
			case 1:
				System.out.print("\nWhat would you like to change the pic to?: ");
				temp = input.nextLine();
				//input.nextLine();
				contact.setPic(temp);
				break;
			case 2:
				System.out.print("\nWhat would you like to change the name to?: ");
				temp = input.nextLine();
				//input.nextLine();
				contact.setName(temp);
				break;
			case 3:
				System.out.print("\nWhat would you like to change the email to?: ");
				temp = input.nextLine();
				//input.nextLine();
				contact.setEmail(temp);
				break;
			case 4:
				System.out.print("\nWhat would you like to change the number to?: ");
				temp = input.nextLine();
				//input.nextLine();
				contact.setNumber(temp);
				break;
			case 5:
				System.out.print("\nWhat would you like to change the street to?: ");
				temp = input.nextLine();
				//input.nextLine();
				contact.setStreet(temp);
				break;
			case 6:
				System.out.print("\nWhat would you like to change the city to?: ");
				temp = input.nextLine();
				input.nextLine();
				contact.setCity(temp);
				break;
			case 7:
				System.out.print("\nWhat would you like to change the state to?: ");
				temp = input.nextLine();
				//input.nextLine();
				contact.setState(temp);
				break;
			case 8:
				System.out.print("\nWhat would you like to change the ZIP code to?: ");
				temp = input.nextLine();
				//input.nextLine();
				contact.setZip(temp);
				break;
			case 9:
				System.out.print("\nWhat would you like to change the country to?: ");
				temp = input.nextLine();
				//input.nextLine();
				contact.setCountry(temp);
				break;
			case 10:
				boolean stay = true;
				do {
					System.out.print("\nWould you like this persone to be a favorite?(y/n): ");
					temp = input.nextLine();
					//input.nextLine();
					if(temp.toLowerCase().charAt(0) == 'y') {
						stay = false;
						contact.setFavorite(true);
					}
					else if(temp.toLowerCase().charAt(0) == 'n') {
						stay = false;
						contact.setFavorite(false);
					}
					else {
						System.out.println("\nPlease input yes or no.");
					}
				}while(stay);
				break;
			case 11:
				System.out.print("\nWhat would you like to change the birthday to?: ");
				temp = input.nextLine();
				//input.nextLine();
				contact.setBirthDay(temp);
				break;
			case 12:
				System.out.print("\nWhat would you like to change the description to?: ");
				temp = input.nextLine();
				//input.nextLine();
				contact.setDescription(temp);
				break;
			case 0:
				exit = true;
				break;
				
			default:
				System.out.println(num +" is not a valid selection.");
			}
				
		}while(!exit);
	}
}
