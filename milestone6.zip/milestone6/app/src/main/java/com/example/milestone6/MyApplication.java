package com.example.milestone6;

import android.app.Application;

import com.example.milestone6.IO.addressBook;
import com.example.milestone6.IO.businessService;
import com.example.milestone6.IO.fileIOService;

public class MyApplication extends Application {

    private fileIOService fileIO = new fileIOService();
    private businessService BService  = new businessService();
    private addressBook contacts = BService.getAddressBook();

    public fileIOService getFileIO() {
        return fileIO;
    }

    public void setFileIO(fileIOService fileIO) {
        this.fileIO = fileIO;
    }

    public businessService getBService() {
        return BService;
    }

    public void setBService(businessService BService) {
        this.BService = BService;
    }

    public addressBook getContacts() {
        return contacts;
    }

    public void setContacts(addressBook contacts) {
        this.contacts = contacts;
    }
}
