package com.example.milestone6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import com.example.milestone6.contacts.*;
import com.example.milestone6.IO.*;

import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button b_addPerson , b_sortName , b_sortEmail;
    ListView lv_contacts;
    businessService BService;
    fileIOService fileIO;
    addressBook contacts;
    PersonAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initializing my globals
        BService = ((MyApplication) this.getApplication()).getBService();
        fileIO = ((MyApplication) this.getApplication()).getFileIO();
        contacts = ((MyApplication) this.getApplication()).getContacts();
        BService.loadContacts(getApplicationContext());
        adapter = new PersonAdapter(MainActivity.this , BService);

        b_addPerson = findViewById(R.id.b_addPerson);
        lv_contacts = findViewById(R.id.lv_contacts);
        b_sortName = findViewById(R.id.b_sortName);
        b_sortEmail = findViewById(R.id.b_sortEmail);

        BService.updateContactList();

        //contacts.addContact(new personContact("Hagen.jpg" , "Ian Hagen" , "tf2@gmail.com" , "6612963236" ,  "Raintree Ln" , "Santa Clarita" , "CA", "91390" , "United States" , true , "10/21/199" , "TF2 god"));
        //contacts.addContact(new businessContact("BuRGer.png" , "HabitBurger" , "HabitBurger@hotmail.com" , "66113123123" ,  "McBean pkwy" , "Hueston" , "CA", "91390" , "United States" , false , "9-17:00 Mon-Thur" , "www.Habit.com" ));

        //handles whether a contact has been edited
        Bundle incomingIntent = getIntent().getExtras();
        if(incomingIntent != null){
            String name = incomingIntent.getString("name");
            String number  = incomingIntent.getString("number");
            String field1  = incomingIntent.getString("field1");
            String field2  = incomingIntent.getString("field2");
            String email  = incomingIntent.getString("email");
            String street  = incomingIntent.getString("street");
            String city  = incomingIntent.getString("city");
            String state  = incomingIntent.getString("state");
            String zip  = incomingIntent.getString("zip");
            String country  = incomingIntent.getString("country");

            //if the contact is being edited, it removes the previous one
            if(contacts.searchFor("name" , name) != null) {
                contacts.removeContact(name);
            }

            if(incomingIntent.getString("type").equals("business")){
                contacts.addContact(new businessContact("",name,email,number,street,city,state,zip,country,false, field1,field2));
            }
            else if(incomingIntent.getString("type").equals("delete")){

            }
            else{
                contacts.addContact(new businessContact("",name,email,number,street,city,state,zip,country,false, field1,field2));
            }
            BService.updateContactList();
            adapter.notifyDataSetChanged();
        }
        BService.saveContacts(getApplicationContext());

        lv_contacts.setAdapter(adapter);

        b_addPerson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(),DecideContactType.class);
                startActivity(i);
                //Toast.makeText(MainActivity.this, "This button is working", Toast.LENGTH_SHORT).show();
            }
        });
        b_sortName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BService.setContactList(BService.getAddressBook().sortBy("name", true));
                adapter.notifyDataSetChanged();
                //Toast.makeText(MainActivity.this, "This button is working", Toast.LENGTH_SHORT).show();
            }
        });
        b_sortEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BService.setContactList(BService.getAddressBook().sortBy("email", true));
                adapter.notifyDataSetChanged();
                //Toast.makeText(MainActivity.this, "This button is working", Toast.LENGTH_SHORT).show();
            }
        });
        lv_contacts.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                editPerson(position);
            }
        });


    }
    public void editPerson(int position){
        List<baseContact> tempList = BService.getContactList();
        if(tempList.get(position).getClass() == businessContact.class){
            Intent i =  new Intent(getApplicationContext() , newBusinessContact.class);

            businessContact p = (businessContact) tempList.get(position);
            i.putExtra("edit" , position);
            i.putExtra("name", p.getName());
            i.putExtra("number" , p.getNumber());
            i.putExtra("field1" , p.getHours());
            i.putExtra("field2" , p.getURL());
            i.putExtra("email" , p.getEmail());
            i.putExtra("street" , p.getStreet());
            i.putExtra("city" , p.getCity());
            i.putExtra("state" , p.getState());
            i.putExtra("zip" , p.getZip());
            i.putExtra("country" , p.getCountry());

            startActivity(i);
        }
        else{
            Intent i =  new Intent(getApplicationContext() , newPersonContact.class);

            personContact p = (personContact) tempList.get(position);
            i.putExtra("edit" , position);
            i.putExtra("name", p.getName());
            i.putExtra("number" , p.getNumber());
            i.putExtra("field1" , p.getBirthDay());
            i.putExtra("field2" , p.getDescription());
            i.putExtra("email" , p.getEmail());
            i.putExtra("street" , p.getStreet());
            i.putExtra("city" , p.getCity());
            i.putExtra("state" , p.getState());
            i.putExtra("zip" , p.getZip());
            i.putExtra("country" , p.getCountry());

            startActivity(i);
        }
    }
}
