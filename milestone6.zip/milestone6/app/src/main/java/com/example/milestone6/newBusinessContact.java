package com.example.milestone6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class newBusinessContact extends AppCompatActivity{
    Button b_okay , b_cancel , b_delete;
    EditText et_name , et_number , et_field1 , et_field2 , et_email,et_street , et_city, et_state, et_zip , et_country;
    int positionToEdit = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.business_contact);

        b_okay = findViewById(R.id.b_submit);
        b_cancel = findViewById(R.id.b_cancel);
        et_name = findViewById(R.id.et_name);
        et_number = findViewById(R.id.et_number);
        et_field1 = findViewById(R.id.et_field1);
        et_field2 = findViewById(R.id.et_field2);
        et_email = findViewById(R.id.et_email);
        et_street = findViewById(R.id.et_street);
        et_city = findViewById(R.id.et_city);
        et_state = findViewById(R.id.et_state);
        et_zip = findViewById(R.id.et_zip);
        et_country = findViewById(R.id.et_country);
        b_delete = findViewById(R.id.b_delete);

        //listen for data
        Bundle incomingIntent = getIntent().getExtras();

        if(incomingIntent != null){
            String name = incomingIntent.getString("name");
            String number  = incomingIntent.getString("number");
            String field1  = incomingIntent.getString("field1");
            String field2  = incomingIntent.getString("field2");
            String email  = incomingIntent.getString("email");
            String street  = incomingIntent.getString("street");
            String city  = incomingIntent.getString("city");
            String state  = incomingIntent.getString("state");
            String zip  = incomingIntent.getString("zip");
            String country  = incomingIntent.getString("country");

            et_name.setText(name);
            et_number.setText(number);
            et_field1.setText(field1);
            et_field2.setText(field2);
            et_email.setText(email);
            et_street.setText(street);
            et_city.setText(city);
            et_state.setText(state);
            et_zip.setText(zip);
            et_country.setText(country);

            positionToEdit = incomingIntent.getInt("edit");
        }

        b_okay.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //get info from text fields
                String newName = et_name.getText().toString();
                String newNumber  = et_number.getText().toString();
                String newField1  = et_field1.getText().toString();
                String newField2  = et_field2.getText().toString();
                String newEmail  = et_email.getText().toString();
                String newStreet  = et_street.getText().toString();
                String newCity  = et_city.getText().toString();
                String newState  = et_state.getText().toString();
                String newZip  = et_zip.getText().toString();
                String newCountry  = et_country.getText().toString();

                Intent i = new Intent(v.getContext(), MainActivity.class);
                i.putExtra("edit" , positionToEdit);
                i.putExtra("name" , newName);
                i.putExtra("number" , newNumber);
                i.putExtra("field1" , newField1);
                i.putExtra("field2" , newField2);
                i.putExtra("email" , newEmail);
                i.putExtra("street" , newStreet);
                i.putExtra("city" , newCity);
                i.putExtra("state" , newState);
                i.putExtra("zip" , newZip);
                i.putExtra("country" , newCountry);
                i.putExtra("type" , "business");

                startActivity(i);
            }
        });
        b_cancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(),MainActivity.class);
                startActivity(i);
                //Toast.makeText(MainActivity.this, "This button is working", Toast.LENGTH_SHORT).show();
            }
        });
        b_delete.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //get info from text fields
                String newName = et_name.getText().toString();
                String newNumber  = et_number.getText().toString();
                String newField1  = et_field1.getText().toString();
                String newField2  = et_field2.getText().toString();
                String newEmail  = et_email.getText().toString();
                String newStreet  = et_street.getText().toString();
                String newCity  = et_city.getText().toString();
                String newState  = et_state.getText().toString();
                String newZip  = et_zip.getText().toString();
                String newCountry  = et_country.getText().toString();

                Intent i = new Intent(v.getContext(), MainActivity.class);
                i.putExtra("edit" , positionToEdit);
                i.putExtra("name" , newName);
                i.putExtra("number" , newNumber);
                i.putExtra("field1" , newField1);
                i.putExtra("field2" , newField2);
                i.putExtra("email" , newEmail);
                i.putExtra("street" , newStreet);
                i.putExtra("city" , newCity);
                i.putExtra("state" , newState);
                i.putExtra("zip" , newZip);
                i.putExtra("country" , newCountry);
                i.putExtra("type" , "delete");

                startActivity(i);
            }
        });

    }
}
