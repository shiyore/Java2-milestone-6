package com.example.milestone6.IO;

import android.content.Context;
import android.util.Log;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.example.milestone6.contacts.*;

import java.io.*;
/**
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
 **/

public class fileIOService implements DataAccessService {
	Context context;
	addressBook contacts;


	public fileIOService() {
	}

	public fileIOService(Context context) { this.context = context; }

	@Override
	public void writeAllData(addressBook contacts) {
		// TODO Auto-generated method stub
		//System.out.println("ran the write all data!!!!!!11");
		ObjectMapper om = new ObjectMapper();
		contactList list = new contactList();
		list.setContactsFromMap(contacts.getContacts());

		File path = context.getExternalFilesDir(null);
		File file = new File(path , "Contacts.json");
		try {
			om.writerWithDefaultPrettyPrinter().writeValue(file,list);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//will later on read data from a text file
	@Override
	public contactList readAllData() {
		// TODO Auto-generated method stub
		System.out.println("LOADING CONTACTS!!!!!!!!!");
		ObjectMapper om = new ObjectMapper();
		contactList temp = new contactList();
		File path = context.getExternalFilesDir(null);
		File file = new File(path , "Contacts.json");
		try {
			temp = om.readValue(file, contactList.class);
			return temp;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (baseContact n : temp.getContacts()){
			System.out.println(n.getName());
		}
		return temp;
	}
	
	public static void main(String[] args) {
		businessService BService = new businessService();
		//BService.loadContacts();
		
	}

}
